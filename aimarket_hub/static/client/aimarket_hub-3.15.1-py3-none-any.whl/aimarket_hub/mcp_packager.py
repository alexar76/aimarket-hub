"""MCP-Server-as-a-Product (#9)

Each product packaged as Docker image + MCP manifest + connection string.
Buyer: docker run aifactory/lyra → local MCP-server, Claude Desktop one-click.

Self-hosted distribution, subscription payment. Path to Anthropic MCP-registry
where "commercial MCP servers" niche is currently vacant.

**What this module actually produces: text.** Read it as a generator of install
instructions, not as a product, because three things it appears to promise are not here:

* The image names it composes (``aifactory/<name>:2.0.0``) are strings. The ``aifactory``
  namespace exists on Docker Hub; the images do not — checked 2026-08-28, `aifactory/echo`
  and `aifactory/hub` both 404. Nothing in this repo builds or pushes them.
* The subscription tiers ($9.99 / $49.99 / $299.99) are dict literals dropped into a
  manifest. There is no subscription record, no metering, no entitlement check, and
  ``AIFACTORY_LICENSE_KEY`` — which the generated config tells the buyer to set — has no
  reader anywhere in the codebase.
* Nothing in the hub calls this class. Its only importer is its own test module.

The class is kept because the manifest shape is right and the generated Claude Desktop
config is correct; what is missing is a build pipeline and a billing surface. If you want a
paid MCP surface today, the hub's own credits rail is the one that moves money — see
``aimarket_hub/credits.py`` and ``docs/operator-quickstart.md``.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class MCPServerPackage:
    """A packaged MCP server for a capability/product."""

    name: str  # e.g., "aifactory/lyra"
    version: str  # e.g., "2.0.0"
    capability_id: str
    product_id: str
    docker_image: str  # e.g., "aifactory/lyra:2.0.0"
    docker_compose_snippet: str
    mcp_manifest: dict[str, Any]  # MCP-compatible manifest
    connection_string: str  # For Claude Desktop
    env_template: dict[str, str] = field(default_factory=dict)
    subscription_tiers: list[dict[str, Any]] = field(default_factory=list)
    license_required: bool = True


class MCPPackager:
    """Package capabilities as self-hosted MCP servers.

    Generates Docker images, MCP manifests, and Claude Desktop connection configs.
    """

    def package(
        self,
        capability_id: str,
        product_id: str,
        name: str,
        description: str,
        input_schema: dict[str, Any],
        price_per_call_usd: float = 0.40,
        registry: str = "aifactory",
    ) -> MCPServerPackage:
        """Package a capability as an MCP server product."""
        image_name = f"{registry}/{name.lower()}"
        image_tag = f"{image_name}:2.0.0"

        # MCP-compatible manifest
        mcp_manifest = {
            "protocol": "mcp",
            "version": "1.0",
            "server": {
                "name": f"{name} MCP Server",
                "description": description,
                "vendor": registry,
            },
            "tools": [
                {
                    "name": capability_id,
                    "description": description,
                    "inputSchema": input_schema,
                }
            ],
            "pricing": {
                "model": "subscription",
                "tiers": [
                    {"name": "Starter", "calls_per_month": 100, "price_usd_month": 9.99},
                    {"name": "Pro", "calls_per_month": 1000, "price_usd_month": 49.99},
                    {"name": "Enterprise", "calls_per_month": 10000, "price_usd_month": 299.99},
                ],
            },
        }

        # Docker compose snippet
        docker_compose = (
            f"{name.lower()}:\n"
            f"  image: {image_tag}\n"
            f"  ports:\n"
            f"    - '3100:3100'\n"
            f"  environment:\n"
            f"    - MCP_SERVER_NAME={name}\n"
            f"    - AIFACTORY_LICENSE_KEY=${{AIFACTORY_LICENSE_KEY}}\n"
            f"  restart: unless-stopped"
        )

        # Connection string for Claude Desktop
        connection_string = json.dumps({
            "mcpServers": {
                name.lower(): {
                    "command": "docker",
                    "args": ["run", "-d", "-p", "3100:3100", image_tag],
                    "env": {"AIFACTORY_LICENSE_KEY": "${AIFACTORY_LICENSE_KEY}"},
                }
            }
        }, indent=2)

        return MCPServerPackage(
            name=image_name,
            version="2.0.0",
            capability_id=capability_id,
            product_id=product_id,
            docker_image=image_tag,
            docker_compose_snippet=docker_compose,
            mcp_manifest=mcp_manifest,
            connection_string=connection_string,
            env_template={"AIFACTORY_LICENSE_KEY": "your_license_key_here"},
            subscription_tiers=mcp_manifest["pricing"]["tiers"],
        )

    def generate_dockerfile(self, package: MCPServerPackage) -> str:
        """Generate a Dockerfile for the MCP server."""
        return f"""# MCP Server: {package.name}
# Auto-generated by AIMarket Hub MCP Packager
FROM python:3.12-slim

LABEL org.opencontainers.image.title="{package.name}"
LABEL org.opencontainers.image.vendor="AI-Factory"
LABEL ai-market.capability="{package.capability_id}"
LABEL ai-market.mcp="true"

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .

ENV MCP_SERVER_NAME={package.name.split('/')[-1]}
ENV MCP_SERVER_PORT=3100

EXPOSE 3100
HEALTHCHECK --interval=30s --timeout=3s \\
    CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:3100/health')"

ENTRYPOINT ["python", "-m", "mcp_server"]
"""

    def generate_claude_desktop_config(self, package: MCPServerPackage) -> str:
        """Generate ~/Library/Application Support/Claude/claude_desktop_config.json snippet."""
        return json.dumps({
            "mcpServers": {
                package.name.split("/")[-1]: {
                    "command": "docker",
                    "args": ["run", "--rm", "-i", package.docker_image],
                    "description": package.mcp_manifest["server"]["description"],
                }
            }
        }, indent=2)

    def generate_install_script(self, package: MCPServerPackage) -> str:
        """Generate a one-line install script."""
        return (
            f"#!/bin/bash\n"
            f"# Install {package.name} MCP Server\n"
            f"docker pull {package.docker_image}\n"
            f"echo '✅ {package.name} installed!'\n"
            f"echo 'Add to Claude Desktop: Settings → MCP Servers → Add'\n"
            f"echo '  Command: docker'\n"
            f"echo '  Args: run --rm -i {package.docker_image}'\n"
        )
